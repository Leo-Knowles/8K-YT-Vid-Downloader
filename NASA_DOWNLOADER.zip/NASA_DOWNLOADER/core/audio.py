def build_audio_filters(bass=0):
    filters = []
    if bass > 0:
        filters.append(f"bass=g={bass}")
    return ",".join(filters) if filters else None
