def detect_type(url):
    if "playlist" in url or "list=" in url:
        return "playlist"
    return "video"
