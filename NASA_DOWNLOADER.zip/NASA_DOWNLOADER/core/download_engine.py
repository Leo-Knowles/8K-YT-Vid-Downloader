import os
import yt_dlp
from utils.progress import progress_context

def download(url, folder, mode="video_audio",
             video_opts=None, audio_opts=None):

    opts = {
        "outtmpl": os.path.join(folder, "%(title)s.%(ext)s"),
        "quiet": True,
        "no_warnings": True,
    }

    if mode in ["video_audio", "video_only"]:
        opts["format"] = video_opts.get("format", "bestvideo+bestaudio/best")
        opts["merge_output_format"] = video_opts.get("container", "mp4")

    if mode in ["audio_only"]:
        opts["postprocessors"] = [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": audio_opts.get("codec", "mp3"),
            "preferredquality": audio_opts.get("quality", "192"),
        }]

    with progress_context(opts):
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([url])
