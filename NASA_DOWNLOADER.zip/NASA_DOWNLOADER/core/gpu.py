import subprocess
import platform

def detect_gpu():
    gpu_name = platform.processor() or "Unknown CPU"
    nvenc_available = False

    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            capture_output=True, text=True
        )
        if result.returncode == 0 and result.stdout.strip():
            gpu_name = result.stdout.strip()
            encoders = subprocess.run(["ffmpeg", "-encoders"],
                                      capture_output=True, text=True)
            if "h264_nvenc" in encoders.stdout:
                nvenc_available = True
    except:
        pass

    return gpu_name, nvenc_available
