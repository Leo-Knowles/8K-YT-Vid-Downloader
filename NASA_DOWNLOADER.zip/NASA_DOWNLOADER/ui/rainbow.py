from rich.console import Console
from rich.text import Text

console = Console()
RAINBOW = ["#FF00FF", "#00FFFF", "#00FF00", "#FFFF00", "#FF6600", "#FF0000"]

def rainbow_text(text):
    t = Text()
    for i, char in enumerate(text):
        t.append(char, style=RAINBOW[i % len(RAINBOW)])
    return t

def rprint(text="", end="\n"):
    console.print(rainbow_text(text), end=end)

def rinput(prompt):
    console.print(rainbow_text(prompt), end="")
    value = input()
    console.print(rainbow_text(value))
    return value
