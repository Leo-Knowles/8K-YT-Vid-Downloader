import os
from ui.rainbow import rprint, rinput

def choose_folder():
    base = os.path.expanduser("~")
    folders = {
        "1": os.path.join(base, "Desktop"),
        "2": os.path.join(base, "Downloads"),
        "3": os.path.join(base, "Music"),
        "4": os.path.join(base, "Videos"),
        "5": os.path.join(base, "Documents"),
    }

    rprint("Select download folder:")
    for k, v in folders.items():
        rprint(f"{k}) {os.path.basename(v)}")
    rprint("6) Custom")

    choice = rinput("Choose folder [1-6]: ").strip()

    if choice == "6":
        path = rinput("Enter full path: ").strip()
    else:
        path = folders.get(choice, folders["2"])

    os.makedirs(path, exist_ok=True)
    return path
