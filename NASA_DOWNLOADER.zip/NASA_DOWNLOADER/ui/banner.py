import os
import pyfiglet
from ui.rainbow import console, rainbow_text

def banner():
    try:
        width = os.get_terminal_size().columns
    except:
        width = 80

    art = pyfiglet.figlet_format("NASA DOWNLOADER", font="slant", width=width)
    for line in art.splitlines():
        console.print(rainbow_text(line))
