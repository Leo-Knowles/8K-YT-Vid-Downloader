from rich.progress import Progress, BarColumn, TextColumn

def progress_context(opts):
    progress = Progress(
        BarColumn(),
        TextColumn("{task.percentage:>3.0f}%")
    )

    task = progress.add_task("", total=100)

    def hook(d):
        if d["status"] == "downloading":
            total = d.get("total_bytes") or 1
            downloaded = d.get("downloaded_bytes", 0)
            progress.update(task, completed=downloaded / total * 100)

    opts["progress_hooks"] = [hook]
    return progress
