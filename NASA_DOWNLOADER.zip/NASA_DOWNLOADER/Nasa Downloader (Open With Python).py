import pyperclip
from ui.banner import banner
from ui.rainbow import rprint, rinput
from ui.folder_select import choose_folder
from core.gpu import detect_gpu
from core.download_engine import download
from core.audio import build_audio_filters
from core.url_detector import detect_type


def main():
    banner()
    folder = choose_folder()

    gpu_name, nvenc_available = detect_gpu()
    rprint(f"[SYSTEM] GPU Detected: {gpu_name}")
    rprint(f"[SYSTEM] NVENC Available: {nvenc_available}\n")

    while True:
        url = rinput("Enter YouTube URL (press Enter for clipboard): ").strip()
        if not url:
            url = pyperclip.paste().strip()
            rprint(f"Using clipboard URL: {url}")

        if not url:
            rprint("No URL provided\n")
            continue

        content_type = detect_type(url)
        rprint(f"Detected: {'Playlist 📃' if content_type=='playlist' else 'Single Video 🎬'}")

        rprint("1) Video & Audio")
        rprint("2) Video Only")
        rprint("3) Audio Only")
        dtype = rinput("Choose type [1-3]: ").strip()
        mode_map = {"1": "video_audio", "2": "video_only", "3": "audio_only"}
        download_mode = mode_map.get(dtype, "video_audio")

        video_opts = {}
        audio_opts = {}

        # ===== VIDEO SETTINGS =====
        if download_mode != "audio_only":
            container = rinput("Video container (mp4/mkv/mov/avi default mp4): ").strip() or "mp4"
            video_opts["container"] = container
            video_opts["format"] = "bestvideo+bestaudio/best"

            # 🚀 If mp4 → skip audio questions
            if container != "mp4" and download_mode != "video_only":
                audio_opts["codec"] = rinput("Audio format (mp3/m4a/flac default mp3): ").strip() or "mp3"
                audio_opts["quality"] = rinput("Bitrate (192 default): ").strip() or "192"

        # ===== AUDIO ONLY SETTINGS =====
        if download_mode == "audio_only":
            audio_opts["codec"] = rinput("Audio format (mp3 default): ").strip() or "mp3"
            audio_opts["quality"] = rinput("Bitrate (192 default): ").strip() or "192"
            bass = rinput("Bass boost (0 default): ").strip()
            bass = int(bass) if bass.isdigit() else 0
            audio_opts["filters"] = build_audio_filters(bass=bass)

        download(url, folder, mode=download_mode,
                 video_opts=video_opts,
                 audio_opts=audio_opts)

        rprint("✅ Download complete!\n")
        again = rinput("Download another? (y/n): ").lower()
        if again != "y":
            break


if __name__ == "__main__":
    main()
